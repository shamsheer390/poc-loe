/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Component, EventEmitter, Input, Output, SimpleChanges} from '@angular/core';

@Component({
  selector: 'annual-wise-bar-chart-test',
  templateUrl: './annual-wise-bar-chart.component.html',
  styleUrls: ['./annual-wise-bar-chart.component.css']
})

export class AnnualWiseBarChartComponent {

  public isBarChartShow: boolean = false;

  @Input()
  yearlyBarChartLabel: Array<string> = [] ;
  @Input()
  yearlyBarChartData: Array<number> = [] ;

  @Output()
  clickEventInfo: EventEmitter<any> = new EventEmitter() ;

  public barChartLabels: string[] = [];
  public barChartType: string = 'bar';
  public barChartLegend: boolean = true;
  public barChartDatas: any[] = [];

  public barChartOptions: any = {
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    },
    scaleShowVerticalLines: false,
    responsive: true
  };

  colors = [
    {
      backgroundColor: [
        '#ffa1b5',
        '#86c7f3',
        '#ffe29a',
        '#cfabc9',
        '#afdaf7',
        '#7986CB',
        '#F48FB1',
        '#40C4FF',
        '#FF8A80',
        '#66BB6A',
        '#FFCA28',
        '#BDBDBD',
        '#795548',
        '#afdaf7',
        '#7986CB',
        '#F48FB1',
        '#40C4FF'
      ]
    }
  ];

  constructor() {}

  ngOnChanges(changes: SimpleChanges) {
    let chartLabel = changes['yearlyBarChartLabel'] ;
    let chartData = changes['yearlyBarChartData'] ;

    if (chartData) {
      if (chartData.currentValue) {
        if (chartData.currentValue.length > 0) {
          this.barChartLabels = chartLabel.currentValue ;
          this.barChartDatas = chartData.currentValue ;
          this.isBarChartShow = true ;
        }
      }
    }

  }

  // events
  public chartClicked(e: any): void {
    console.log('clicked', e) ;
    if ( e.active.length > 0) {
      let clickInfo = {
        'index': e.active[0]._index,
        'data': e.active[0]._chart.config.data.datasets[0].data[e.active[0]._index],
        'label': e.active[0]._chart.config.data.labels[e.active[0]._index]
      };
      this.clickEventInfo.emit(clickInfo);
    }
  }
}
