/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Component, EventEmitter, Input, OnInit, Output, SimpleChanges} from '@angular/core';

@Component({
  selector: 'monthly-vender-pie-chart-test',
  templateUrl: './monthly-vender-pie-chart.component.html',
  styleUrls: ['./monthly-vender-pie-chart.component.css']
})

export class MonthlyVenderPieChartComponent implements OnInit {

  public isPieChartShow: boolean = false;

  @Input()
  pieChartLabel: Array<any>;
  @Input()
  pieChartData: Array<any>;
  @Input()
  venderName: string;

  @Output()
  clickEventInfo: EventEmitter<any> = new EventEmitter() ;
  @Output()
  closeButtonEvent: EventEmitter<any> = new EventEmitter() ;

  public selectedVenderName: string ;

  public pieChartLabels: string[] = [];
  public pieChartDatas: number[] = [];
  public pieChartType: string = 'pie';

  constructor() {}

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    let pieChartLabel = changes['pieChartLabel'];
    let pieChartData = changes['pieChartData'];
    let _venderName = changes['venderName'];

    if (pieChartLabel) {
      if (pieChartLabel.currentValue ) {
        if ( pieChartLabel.currentValue.length > 0 ) {
          this.pieChartLabels = pieChartLabel.currentValue;
          this.pieChartDatas = pieChartData.currentValue;
          this.isPieChartShow = true;
        }
      }
    }

    if (_venderName) {
      if (_venderName.currentValue) {
        if ( _venderName.currentValue.length > 0 ) {
          this.selectedVenderName = _venderName.currentValue;
        }
      }
    }
  }

  // events
  public chartClicked(e: any): void {
    if ( e.active.length > 0) {
      let clickInfo = {
        'index': e.active[0]._index,
        'data': e.active[0]._chart.config.data.datasets[0].data[e.active[0]._index],
        'label': e.active[0]._chart.config.data.labels[e.active[0]._index]
      };
      this.clickEventInfo.emit(clickInfo);
    }
  }

  public closeButtonClicked( e: any): void {
    this.closeButtonEvent.emit(true) ;
  }
}
