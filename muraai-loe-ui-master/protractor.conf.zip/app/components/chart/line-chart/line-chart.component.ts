/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Component, EventEmitter, Input, Output, SimpleChanges} from '@angular/core';

@Component({
  selector: 'line-chart-test',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.css'],
  providers: []
})

export class LineChartComponent  {

  public isBarChartShow: boolean = false ;

  @Input()
  getlineChartLabel: Array<string> = [] ;
  @Input()
  getlineChartData: Array<number> = [] ;

  @Output()
  clickEventInfo: EventEmitter<any> = new EventEmitter() ;
  @Output()
  closeButtonEvent: EventEmitter<any> = new EventEmitter() ;

  // lineChart
  public lineChartData: Array<any> = [];
  public lineChartLabels: Array<any> = [];

  public lineChartOptions: any = {
    responsive: true
  };

  public lineChartColors: Array<any> = [
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#1d5780',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    },
    { // dark grey
      backgroundColor: 'rgba(77,83,96,0.2)',
      borderColor: 'rgba(77,83,96,1)',
      pointBackgroundColor: 'rgba(77,83,96,1)',
      pointBorderColor: '#1d5780',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(77,83,96,1)'
    },
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#1d5780',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend: boolean = true;
  public lineChartType: string = 'line';

  ngOnChanges(changes: SimpleChanges) {
    let chartLabel = changes['getlineChartLabel'] ;
    let chartData = changes['getlineChartData'] ;

    if (chartData) {
      if (chartData.currentValue) {
        if (chartData.currentValue.length > 0) {
          this.lineChartLabels = chartLabel.currentValue ;
          this.lineChartData = chartData.currentValue ;
          this.isBarChartShow = true ;
        }
      }
    }

  }

  // events
  public chartClicked(e: any): void {
    console.log('clicked', e) ;
    if ( e.active.length > 0) {
      let clickInfo = {
        'index': e.active[0]._index,
        'data': e.active[0]._chart.config.data.datasets[0].data[e.active[0]._index],
        'label': e.active[0]._chart.config.data.labels[e.active[0]._index]
      };
      this.clickEventInfo.emit(clickInfo);
    }
  }

  public closeButtonClicked( e: any): void {
    this.closeButtonEvent.emit(true) ;
  }
}
