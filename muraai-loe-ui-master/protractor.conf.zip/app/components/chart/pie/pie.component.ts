/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Component, EventEmitter, Input, OnInit, Output, SimpleChanges} from '@angular/core';

@Component({
  selector: 'pie-chart-test',
  templateUrl: './pie.component.html',
  styleUrls: ['./pie.component.css']
})

export class PieChartComponent implements OnInit {

  public isPieChartShow: boolean = false;

  @Input() pieChartLabel: Array<any>;
  @Input() pieChartData: Array<any>;

  @Output() clickEventInfo: EventEmitter<any> = new EventEmitter() ;

  public pieChartLabels: string[] = [];
  public pieChartDatas: number[] = [];
  public pieChartType: string = 'pie';

  constructor() {}

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    let pieChartLabel = changes['pieChartLabel'];
    let pieChartData = changes['pieChartData'];

    if (pieChartLabel) {
      if (pieChartLabel.currentValue) {
        if ( pieChartLabel.currentValue.length > 0 ) {
          this.pieChartLabels = pieChartLabel.currentValue;
          this.pieChartDatas = pieChartData.currentValue;
          this.isPieChartShow = true;
        }
      }
    }
  }

  // events
  public chartClicked(e: any): void {
    if ( e.active.length > 0) {
      let clickInfo = {
        'index': e.active[0]._index,
        'data': e.active[0]._chart.config.data.datasets[0].data[e.active[0]._index],
        'label': e.active[0]._chart.config.data.labels[e.active[0]._index]
      };
      this.clickEventInfo.emit(clickInfo);
    }
  }
}
