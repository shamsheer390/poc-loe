/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Pagination } from 'alfresco-js-api';
import { MenuUserGroupEntityMasterService } from './services/menu-user-group-entity.service';
import { PageEvent } from '@angular/material';
import { MenuUserGroupEntityMappingMasterModel } from '../../models/menu-user-group-entity-mapping.model';
import { FieldDetails } from '../../models/mu-field.model';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
@Component({
    selector: 'menu-user-group-entity-master',
    templateUrl: './menu-user-group-entity.component.html',
    styleUrls: ['./menu-user-group-entity.component.scss'],
    providers: [MenuUserGroupEntityMasterService]
})
export class MenuUserGroupEntityMasterComponent implements OnInit {
    PERPAGEITEMSIZE: number = 5;
    detailsPagination: Pagination;
    menuUserGroupEntityMappingMasterModel: MenuUserGroupEntityMappingMasterModel;
    formData: FieldDetails<any>[];
    selectionMode: string = 'none';
    deletedRecord = [];
    menuMasterList = [];
    userMasterList = [];
    groupMasterList = [];
    statusMasterList = [];
    updatedUserEntityMenuGroupValue = [];
    searchData = {};
    isSearch: boolean = false;
    getAllMenuEntityUserData = [];
    copyOfAllMenuEntityUserData = [];
    searchFormField: FieldDetails<any>[];
    entityMasterList = [];
    newAddedRecords = [];
    showAdd: boolean = true;
    showRemove: boolean = true;
    showSave: boolean = true;
    pageEvent: PageEvent;
    mutltiSelect: boolean = true; // this property for enabled checkBox for select
    header = 'MenuUserGroupEntityMapping';
    addHeader = 'Add entity';
    editHeader = 'Edit entity';
    showPagination: boolean = true;
    constructor(private menuUserGroupEntityMasterService: MenuUserGroupEntityMasterService, public toastr: ToastsManager, vcr: ViewContainerRef) {
        this.toastr.setRootViewContainerRef(vcr);
    }
    ngOnInit() {
        this.searchData = {};
        this.searchPageJson();
        this.getAllMenuMaster();
        this.getAllEntityMaster();
        this.getAllUserMaster();
        this.getAllGroupMaster();
        this.getAllStatusMasters();
        this.getAllMenuUserEntityGroupMapping(0, this.PERPAGEITEMSIZE, true, true, ''); // this method call when page load to get entity master data
    }
    getAllMenuUserEntityGroupMapping(offset: number, limit: number, isDefaultCall: boolean, isNotSearchCall: boolean, searchText: any) {
        this.menuUserGroupEntityMasterService.getAllMenuUserGroupEntityMaster(offset, limit, this.searchData).subscribe((res: any) => {
            this.getAllMenuEntityUserData = res.content;
            this.showPagination = true;
            if (this.getAllMenuEntityUserData.length === 0) { // this for pagination will be hide when no data
                this.showPagination = false;
            }
            this.copyOfAllMenuEntityUserData = JSON.parse(JSON.stringify(res.content));
            if (isDefaultCall) {
                if (res.totalElements > this.PERPAGEITEMSIZE) {
                    this.detailsPagination = { count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: 5, hasMoreItems: true };
                } else {
                    this.detailsPagination = { count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: 5, hasMoreItems: false };
                }
            }
        });
    }
    onAdd(data) {
        this.menuUserGroupEntityMappingMasterModel = new MenuUserGroupEntityMappingMasterModel();
        this.getAllMenuEntityUserData.unshift(this.menuUserGroupEntityMappingMasterModel);
    }
    onDelete(result): void {// this method for delete the single entity or multiple entity
        this.deletedRecord = [];
        if (result.length > 0) {
            result.forEach(element => {
                if (element.menuUserGroupEntityId !== null) {
                    this.deletedRecord.push(element.menuUserGroupEntityId);
                }
            });
            if (this.deletedRecord.length > 0) {
                this.menuUserGroupEntityMasterService.deleteMenuUserGroupEntityMapping(this.deletedRecord).subscribe((res: any) => {
                    // this.toastr.success(res.message, 'Success!');
                    this.getAllMenuEntityUserData = this.getAllMenuEntityUserData.filter(function (el) {
                        return result.indexOf(el) < 0;
                    });
                }, (err) => {
                    // this.toastr.error(err.message, 'Error!');
                    console.log(JSON.stringify(err));
                });
            } else {
                this.toastr.success('Succesfully Deleted', 'Success!');
                this.getAllMenuEntityUserData = this.getAllMenuEntityUserData.filter(function (el) {
                    return result.indexOf(el) < 0;
                });
            }
        }
    }
    processDetailPagination(event: Pagination): void { //  this method call when user click  left or right arror of pagination
        let noOfStep = 0;
        if (event.skipCount !== 0) {
            noOfStep = event.skipCount / event.count;
        }
        this.detailsPagination = {
            count: event.maxItems,
            totalItems: event.totalItems,
            skipCount: event.skipCount,
            maxItems: event.maxItems,
            hasMoreItems: this.isNextPagination(noOfStep, event.totalItems, event.count)
        };
        if (event.maxItems > event.totalItems) {
            this.getAllMenuUserEntityGroupMapping(0, event.totalItems, false, true, '');
        } else {
            this.getAllMenuUserEntityGroupMapping(this.detailsPagination.skipCount / event.maxItems, event.maxItems, false, true, '');
        }
    }

    changeSizeItemDetailPagi(event: Pagination): void {
        this.detailsPagination = { count: event.maxItems, totalItems: event.totalItems, skipCount: 0, maxItems: event.maxItems, hasMoreItems: true };
        this.processDetailPagination(this.detailsPagination);
    }
    private isNextPagination(noOfStep: number, totalItem: number, count: number): boolean {
        return ((++noOfStep) * count) < totalItem;
    }
    onSearchResponse(event) {
        console.log(event);
        if (event.entityName !== undefined) {
            this.searchData = event;
        } else {
            this.searchData = { 'param': event };
        }
        this.getAllMenuUserEntityGroupMapping(0, this.PERPAGEITEMSIZE, true, true, '');
    }

    updateMenuUserEntity(data, event, type) {
        if (data === 'default' && type === 'menu') {
            event.menuId = null;
        }
        if (data === 'default' && type === 'user') {
            event.userId = null;
        }
        if (data === 'default' && type === 'group') {
            event.groupId = null;
        }
        if (data === 'default' && type === 'entity') {
            event.entityId = null;
        }
        if (data === 'default' && type === 'status') {
            event.status = null;
        }
    }
    getAllMenuMaster() {
        this.menuUserGroupEntityMasterService.getAllMenuMaster().subscribe((res: any) => {
            this.menuMasterList = (res);
        }, (err) => {
            console.log(JSON.stringify(err));
        });
    }
    getAllEntityMaster() {
        this.menuUserGroupEntityMasterService.getAllEntityMaster().subscribe((res: any) => {
            this.entityMasterList = res;
        }, (err) => {
            console.log(JSON.stringify(err));
        });
    }
    getAllUserMaster() {
        this.menuUserGroupEntityMasterService.getAllUserMaster().subscribe((res: any) => {
            this.userMasterList = res;
        }, (err) => {
            console.log(JSON.stringify(err));
        });
    }
    getAllGroupMaster() {
        this.menuUserGroupEntityMasterService.getAllGroupMaster().subscribe((res: any) => {
            this.groupMasterList = res;
        }, (err) => {
            console.log(JSON.stringify(err));
        });
    }

    getAllStatusMasters() {
        this.menuUserGroupEntityMasterService.getAllStatusMaster().subscribe((res: any) => {
            this.statusMasterList = res;
        }, (err) => {
            console.log(JSON.stringify(err));
        });

    }
    saveAllMenuUserEntityGroupMapping(event) {
        this.updatedUserEntityMenuGroupValue = [];
        this.newAddedRecords = [];
        this.newAddedRecords = event.filter(item => (item.menuUserGroupEntityId === null));
        event = event.filter(item => (item.menuUserGroupEntityId !== null));
        for (let i = 0; i < event.length; i++) {
            let row = this.copyOfAllMenuEntityUserData[i];
            if (event[i].menuId !== row.menuId || event[i].userId !== row.userId || event[i].entityId !== row.entityId
                || event[i].groupId !== row.groupId || event[i].status !== row.status) {
                this.updatedUserEntityMenuGroupValue.push(event[i]);
            }
        }
        this.updatedUserEntityMenuGroupValue = this.updatedUserEntityMenuGroupValue.concat(this.newAddedRecords);
        this.menuUserGroupEntityMasterService.saveMenuUserGroupEntityMapping(this.updatedUserEntityMenuGroupValue).subscribe((res: any) => {
            console.log(res);
            this.toastr.success('Succesfully Saved', 'Success!');
            this.getAllMenuUserEntityGroupMapping(0, this.PERPAGEITEMSIZE, true, true, '');
        }, (err) => {
            err = JSON.parse(JSON.stringify(err._body));
            this.toastr.error(err, 'Error!');
        });
    }
    searchPageJson() {
        this.searchFormField = [
            {
                label: 'First Name',
                id: 'firstName',
                name: 'firstName',
                type: 'text',
                controlType: 'textbox',
                placeholder: 'Enter First Name',
                visibility: true,
                disabled: false,
                cssClass: 'mu-inputField',
                width: 6,
                value: null
            },
            {
                label: 'Last Name',
                id: 'lastName',
                name: 'lastName',
                type: 'text',
                controlType: 'textbox',
                placeholder: 'Enter last Name',
                visibility: true,
                disabled: false,
                cssClass: 'mu-inputField',
                width: 6,
                value: null
            },
            {
                label: 'Entity Name',
                id: 'entityName',
                name: 'entityName',
                type: 'text',
                controlType: 'textbox',
                placeholder: 'Enter Entity Name',
                visibility: true,
                disabled: false,
                cssClass: 'mu-inputField',
                width: 6,
                value: null
            },
            {
                label: 'Menu Name',
                id: 'menuDesc',
                name: 'menuDesc',
                type: 'text',
                controlType: 'textbox',
                placeholder: 'Enter Menu Name',
                visibility: true,
                disabled: false,
                cssClass: 'mu-inputField',
                width: 6,
                value: null
            },
            {
                label: 'Entity Code',
                id: 'entityCode',
                name: 'entityCode',
                type: 'text',
                controlType: 'textbox',
                placeholder: 'Enter Entity Code',
                visibility: true,
                disabled: false,
                cssClass: 'mu-inputField',
                width: 6,
                value: null
            },
            {
                name: 'Search',
                type: 'submit',
                controlType: 'button'
            },
            {
                name: 'Close',
                type: 'button',
                controlType: 'button'
            }
        ];
    }
}
