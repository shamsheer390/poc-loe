/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Pagination } from 'alfresco-js-api';
import { MenuMasterService } from './services/menu-master.service';
import { PageEvent } from '@angular/material';
import { FieldDetails } from '../../models/mu-field.model';
import { MenuMasterModel } from '../../models/menu-master.model';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';

@Component({
    selector: 'menu-master',
    templateUrl: './menu-master.component.html',
    styleUrls: ['./menu-master.component.scss'],
    providers: [MenuMasterService]
})
export class MenuMasterComponent implements OnInit {
    PERPAGEITEMSIZE: number = 5;
    searchData = {};
    formData: FieldDetails<any>[];
    detailsPagination: Pagination;
    selectionMode: string = 'none';
    deletedRecord = [];
    menuMasterModel: MenuMasterModel;
    menuMasterList = [];
    updatedMenuData = [];
    newAddedRecords = [];
    statusMasterList = [];
    isSearch: boolean = false;
    showAdd: boolean = true;
    showSave: boolean = true;
    showRemove: boolean = true;
    getAllMenuData = [];
    copyOfAllMenuData = [];
    pageEvent: PageEvent;
    mutltiSelect: boolean = true; // this property for enabled checkBox for select
    header = 'Menu Master';
    showPagination: boolean = true;
    searchFormField: FieldDetails<any>[] = [
        {
            label: 'Menu Name',
            id: 'menuDesc',
            name: 'menuDesc',
            type: 'text',
            controlType: 'textbox',
            visibility: true,
            placeholder: 'Enter Menu Name',
            disabled: false,
            width: 6,
            value: null
        },
        {
            name: 'Search',
            type: 'submit',
            controlType: 'button'
        },
        {
            name: 'Close',
            type: 'button',
            controlType: 'button'
        }
    ];
    constructor(private menuMastersService: MenuMasterService, public toastr: ToastsManager, vcr: ViewContainerRef) {
        this.toastr.setRootViewContainerRef(vcr);
    }
    ngOnInit() {
        this.getAllMenuMaster();
        this.getAllStatusMasters();
        this.getAllMenu(0, this.PERPAGEITEMSIZE, true, true, ''); // this method call when page load to get Menu master data
    }
    getAllMenu(offset: number, limit: number, isDefaultCall: boolean, isNotSearchCall: boolean, searchText: any) {
        this.menuMastersService.searchMenuMaster(offset, limit, this.searchData).subscribe((res: any) => {
            this.getAllMenuData = res.content;
            this.showPagination = true;
            if (this.getAllMenuData.length === 0) { // this for pagination will be hide when no data
                this.showPagination = false;
            }
            if (isDefaultCall) {
                if (res.totalElements > this.PERPAGEITEMSIZE) {
                    this.detailsPagination = { count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: this.PERPAGEITEMSIZE, hasMoreItems: true };
                } else {
                    this.detailsPagination = { count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: this.PERPAGEITEMSIZE, hasMoreItems: false };
                }
            }
        });
    }
    processDetailPagination(event: Pagination): void { //  this method call when user click  left or right arror of pagination
        let noOfStep = 0;
        if (event.skipCount !== 0) {
            noOfStep = event.skipCount / event.count;
        }
        this.detailsPagination = {
            count: event.maxItems,
            totalItems: event.totalItems,
            skipCount: event.skipCount,
            maxItems: event.maxItems,
            hasMoreItems: this.isNextPagination(noOfStep, event.totalItems, event.count)
        };
        if (event.maxItems > event.totalItems) {
            this.getAllMenu(0, event.totalItems, false, true, '');
        } else {
            this.getAllMenu(this.detailsPagination.skipCount / this.detailsPagination.maxItems, event.maxItems, false, true, '');
        }
    }

    changeSizeItemDetailPagi(event: Pagination): void {
        this.detailsPagination = { count: event.maxItems, totalItems: event.totalItems, skipCount: 0, maxItems: event.maxItems, hasMoreItems: true };
        this.processDetailPagination(this.detailsPagination);
    }
    private isNextPagination(noOfStep: number, totalItem: number, count: number): boolean {
        return ((++noOfStep) * count) < totalItem;
    }
    public onSearchResponse(event): void {
        if (event.menuDesc !== undefined) {
            this.searchData = event;
        } else {
            this.searchData = { 'param': event };
        }
        this.getAllMenu(0, this.PERPAGEITEMSIZE, true, true, '');
    }
    getAllMenuMaster() {
        this.menuMastersService.getAllMenuMaster().subscribe((res: any) => {
            this.menuMasterList = (res);
        }, (err) => {
            console.log(JSON.stringify(err));
        });
    }
    getAllStatusMasters() {
        this.menuMastersService.getAllStatusMaster().subscribe((res: any) => {
            this.statusMasterList = res;
        }, (err) => {
            console.log(JSON.stringify(err));
        });

    }
    onDelete(result): void {// this method for delete the single entity or multiple entity
        this.deletedRecord = [];
        if (result.length > 0) {
            result.forEach(element => {
                if (element.menuId !== null) {
                    this.deletedRecord.push(element.menuId);
                }
            });
            if (this.deletedRecord.length > 0) {
                this.menuMastersService.deleteMenu(this.deletedRecord).subscribe((res: any) => {
                    console.log(res);
                    this.toastr.success(res.message, 'Success!');
                    this.getAllMenuData = this.getAllMenuData.filter(function (el) {
                        return result.indexOf(el) < 0;
                    });
                }, (err) => {
                    this.toastr.error(err.message, 'Error!');
                });
            } else {
                this.toastr.success('Successfully Deleted', 'Success!');
                this.getAllMenuData = this.getAllMenuData.filter(function (el) {
                    return result.indexOf(el) < 0;
                });
            }
        }
    }
    onAdd(data) {
        this.menuMasterModel = new MenuMasterModel();
        this.getAllMenuData.unshift(this.menuMasterModel);
    }
    onSelectChanges(data, event, type) {
        if (data === 'default' && type === 'menu') {
            event.menuId = null;
        }
        if (data === 'default' && type === 'status') {
            event.status = null;
        }
    }
    saveAllMenu(event) {
        this.menuMastersService.saveMenu(event).subscribe((res: any) => {
            this.getAllMenu(0, this.PERPAGEITEMSIZE, true, true, '');
            this.toastr.success('Successfully Saved', 'Success!');
        }, (err) => {
            console.log(JSON.stringify(err));
        });
    }
}
