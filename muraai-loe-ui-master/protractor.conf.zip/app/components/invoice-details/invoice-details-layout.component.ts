/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'invoice-details-layout',
  moduleId: module.id.toString(),
  templateUrl: './invoice-details-layout.component.html',
  styleUrls: ['./invoice-details-layout.component.css']
})
export class InvoiceDetailsLayoutComponent {

  invDetails: any[];
  poNo: string;
  headerId: number;
  invoiceStatus: string;
  isOverLayMode: boolean = true;
  taskRespectedClass: string = 'alf-am-task-form-container';
  detailsRespectedClass: string = 'alf-am-task-details-container';
  /**
   * Constructor
   * @param auth Authentication service
   * @param translate Translation service
   * @param activitiForm Form service
   * @param activitiTaskList Task service
   */
  constructor(private route: ActivatedRoute, private router: Router) {
  }
  ngOnInit() {
   this.poNumber();
  }

  private poNumber(): void {
    this.route.params.subscribe(params => {
    if (params['id'] !== undefined) {
      this.poNo = params['id'];
    }
    this.headerId = params['hid'];
    });
    this.invDetails = [this.poNo, this.headerId];
  }
  onDataSuccess(data: any) {
    this.invoiceStatus = data['invoiceStatus'];
  }

  public fullScreenMode(e: Event) {
    this.isOverLayMode = false;
    this.taskRespectedClass = 'task-container ';
    this.detailsRespectedClass = 'view-container';
  }

  public defaultLayoutMode(e: Event) {
    this.isOverLayMode = true;
    this.taskRespectedClass = 'alf-am-task-form-container';
    this.detailsRespectedClass = 'alf-am-task-details-container';
  }

}
