/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Component, Output, Input, EventEmitter, SimpleChanges, ViewChild} from '@angular/core';
import { InvoiceSummaryService } from '../invoice-summary/services/invoice-summary.service';
import { ObjectDataTableAdapter }  from 'ng2-alfresco-datatable';
import {Pagination} from 'alfresco-js-api';
import { FieldDetails }         from '../../models/mu-field.model';
import { MuraaiFormComponent }  from '../muraai/mu-dynamic-form/src/mu-form.component';
import {ActivatedRoute,  Router} from '@angular/router';
// import { Validators }           from '@angular/forms';
declare var componentHandler: any;

@Component({
  selector: 'invoice-details',
  templateUrl: './invoice-details.component.html',
  styleUrls: ['./invoice-details.component.scss'],
  providers: [InvoiceSummaryService]
})
export class InvoiceDetailsComponent {

  @Input()
  invDetails: any[];

  @Input()
  mode: string;

  @Input()
  taskName: string = '';

  @Output()
  onDataLoaded: EventEmitter<any> = new EventEmitter<any>();

  headerData: any;

  @ViewChild(MuraaiFormComponent) form: MuraaiFormComponent;
  groupFields: Array<MuraaiField>;

  tableFields: Array<MuraaiGrid>;
  @Input()
  poNo: number;

  vendorHeader: string = 'Vendor Bank Details';
  bankHeader: string = 'Invoice Bank Details';
  // Muraai group starts
  formData: FieldDetails<any>[] = [
    {
      label: 'Invoice Number' ,
      id: 'invoiceNo',
      name: 'invoiceNo',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter invoice number',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'PO No' ,
      id: 'invoicePo',
      name: 'invoicePo',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Invoice Date' ,
      id: 'invoiceDate',
      name: 'invoiceDate',
      type: 'date',
      controlType: 'datepicker',
      placeholder: 'Enter from date',
      disabled: false,
      validation: [],
      cssClass: 'mu-inputField',
      width: 3,
      visibility: true
    },
    {
      label: 'PO Value' ,
      id: 'poValue',
      name: 'poValue',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Total Invoice Gross Value' ,
      id: 'totalInvoiceGrossValue',
      name: 'totalInvoiceGrossValue',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Net Invoice Value' ,
      id: 'netInvoiceValue',
      name: 'netInvoiceValue',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Invoice Classification' ,
      id: 'invoiceClassification',
      name: 'invoiceClassification',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Invoice Status' ,
      id: 'invoiceStatus',
      name: 'invoiceStatus',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      width: 3,
      value: '',
      visibility: true
    },
    {
      label: 'Vendor Code' ,
      id: 'vendorCode',
      name: 'vendorCode',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Vendor Name' ,
      id: 'vendorName',
      name: 'vendorName',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Entity Name' ,
      id: 'entityName',
      name: 'entityName',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Entity Code' ,
      id: 'entityCode',
      name: 'entityCode',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'DC No' ,
      id: 'dcNo',
      name: 'dcNo',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Currency' ,
      id: 'currency',
      name: 'currency',
      value: null,
      type: 'select',
      controlType: 'selectbox',
      placeholder: 'Select invoice status',
      options: [{
        key: 'INR',
        value: 'INR'
      },
      {
        key: 'EUR',
        value: 'EUR'
      },
      {
        key: 'USD',
        value: 'USD'
      }],
      validation: [],
      disabled: false,
      cssClass: 'mu-selectField',
      width: 3,
      visibility: true
    },
    {
      label: 'Tax' ,
      id: 'taxPer',
      name: 'taxPer',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Gross Invoice Value' ,
      id: 'invoiceValue',
      name: 'invoiceValue',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Cleared Discount' ,
      id: 'invoiceDiscountVal',
      name: 'invoiceDiscountVal',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Discount' ,
      id: 'invoiceDiscountVal',
      name: 'invoiceDiscountVal',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Amount to be paid' ,
      id: 'invoiceValue',
      name: 'invoiceValue',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: 0,
      visibility: true
    },
    {
      label: 'Three Way Matching Status',
      id: 'threeWayMatchingStatus',
      name: 'threeWayMatchingStatus',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: 0,
      visibility: true
    },
    {
      label: 'Payment Terms',
      id: 'paymentTerms',
      name: 'paymentTerms',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 3,
      value: 0,
      visibility: true
    },
    {
      label: 'Shipping Address' ,
      id: 'shipTo',
      name: 'shipTo',
      type: 'text',
      controlType: 'textbox',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 9,
      value: 0,
      visibility: true
    },
    {
      label: 'Billing Address' ,
      id: 'billingTo',
      name: 'billingTo',
      type: 'text',
      controlType: 'textarea',
      placeholder: '',
      disabled: true,
      cssClass: 'mu-inputField',
      width: 12,
      value: 0,
      visibility: true
    },
    {
      label: 'Requestor' ,
      id: 'requestor',
      name: 'requestor',
      type: 'select',
      controlType: 'selectbox',
      placeholder: 'Select invoice status',
      options: [{
        key: 'AP Requester 1',
        value: 'ap_requestor1@muraai.com'
      },
      {
        key: 'AP Requester 2',
        value: 'ap_requestor2@muraai.com'
      }],
      validation: [],
      disabled: false,
      cssClass: 'mu-selectField',
      width: 3,
      value: null,
      visibility: true
    }
  ];
  data: any = {
    poNumber: '',
    requester: '',
    invoiceStatus: '',
    lineDetails: []
  };
  hideThreeWayMatching: boolean;
  PERPAGEITEMSIZE = 5;
  isPODetails: boolean;
  headerFields: any = [];
  tableHeader: any = [];
  itemList: any[];
  rowList: any[];
  netValue;
  lineItem: number;
  invoiceNumber: any;
  inboundInvoiceDocId: any;
  vendorCode: any;
  vendorCodeDetails:  Array<any> = [];
  lineItemDetails: Array<any> = [];
  threeWayDetails: Array<any> = [];
  threeWayMatchingDetails: ObjectDataTableAdapter;
  bankDetails: ObjectDataTableAdapter;
  vendorDetails: ObjectDataTableAdapter;
  details: ObjectDataTableAdapter;
  invoiceVendorDetails: Array<any>;

  glCodeList: Array<any> = [];
  costCenterList: Array<any> = [];
  lineItemDetailsPagination: Pagination;
  requester: string = 'ap_requestor1@muraai.com';
  taskStatus: string = '';
  detail = [];
  isShow: boolean = true;
  hideDataColumns: boolean;

  constructor(
    private router: Router,
    private route: ActivatedRoute, private invoiceService: InvoiceSummaryService) {
      this.setRequesterList();

  }

  ngOnInit() {

  }

  onDataSuccess(data: any) {
    this.onDataLoaded.emit(data);
  }

  ngAfterViewInit() {
    if (componentHandler) {
      componentHandler.upgradeAllRegistered();
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    let hid;
    let groupData = changes['invDetails'];
    console.log('Group Data : ' + JSON.stringify(groupData));
    if (groupData) {
      if (groupData.currentValue[0]) {
        if (!isNaN(groupData.currentValue )) {
        hid = groupData.currentValue;
      }else {
        hid = groupData.currentValue[1];
      }
        this.invoiceService.getInvoiceHeaderByInvoiceHeaderId(hid).
          subscribe((data: any) => {
            this.data.requester = data.requestor;
            this.data.poNumber = data.invoicePo;
            this.data.invoiceStatus = data.invoiceStatus;
            this.onDataLoaded.emit(this.data);
            this.invoiceNumber = data.invoiceNo;
            this.taskStatus = data.invoiceStatus;
            this.inboundInvoiceDocId = data.inboundInvoiceDocId;
            this.vendorCode = data['vendorCode'];
            if (data.invoicePo === 0 || data.invoicePo === '' || data.invoicePo === undefined || data.invoicePo === null || data.invoicePo === 'NA') {
              this.prpareFields(false, data);
              this.hideThreeWayMatching = false;
            } else {
              this.prpareFields(true, data);
              this.hideThreeWayMatching = true;
            }
          }, (error: any) => {
            console.log('error=>', error);
          });

        this.lineItemDetails = [];
        this.invoiceService.getInvoiceDetailsByInvoiceHeaderId(hid).subscribe(
          (response) => {
            this.lineItemDetails = response;
            this.lineItem = this.lineItemDetails.length;
            if ( this.taskStatus === '' || this.taskStatus === null || this.taskStatus === undefined || this.taskStatus === 'Invoice Approved') {
              this.hideDataColumns = true;
              this.prpareGrid(false, response, this.lineItem);

            } else {
              this.hideDataColumns = false;
              this.prpareGrid(false, response, this.lineItem);
            }
          }
        );
        this.threeWayDetails = [];
        this.invoiceService.getThreeWayDetailsByInvoiceHeaderId(hid).subscribe(
          (response) => {
            this.threeWayDetails = response;
            console.log('Three Way Details' + JSON.stringify(response));
            this.threeWayMatchingDetails = new ObjectDataTableAdapter(this.threeWayDetails,
              [
                {type: 'text', key: 'invoicePo', title: 'Invoice Po', sortable: true},
                {type: 'text', key: 'invQuantity', title: 'Invoice Qty', sortable: true},
                {type: 'text', key: 'invRate', title: 'Invoice Rate', sortable: true},
                {type: 'text', key: 'invMatirialDesc', title: 'Material Desc', sortable: true},
                {type: 'text', key: 'invMatirialCode', title: 'Material Code', sortable: true},
                {type: 'text', key: 'grQty', title: 'Gr Qty', sortable: true},
                {type: 'text', key: 'grMatirialDesc', title: 'Gr Material Desc', sortable: true},
                {type: 'text', key: 'grMatirialCode', title: 'Gr Material Code', sortable: true},
                {type: 'text', key: 'grRejectedQty', title: 'Gr Rejected Qty', sortable: true},
                {type: 'text', key: 'grAsnOrderedQty', title: 'gr Asn Ordered Qty', sortable: true},
                {type: 'text', key: 'grAcceptedQty', title: 'Gr Accepted Qty', sortable: true},
                {type: 'text', key: 'eplOrderQty', title: 'Epl Order Qty', sortable: true},
                {type: 'text', key: 'eplMatirialCode', title: 'Epl Material Code', sortable: true},
                {type: 'text', key: 'eplMatirialDesc', title: 'Epl Material Desc', sortable: true},
                {type: 'text', key: 'eplPrice', title: 'Epl Price', sortable: true},
                {type: 'text', key: 'threeWayMatching', title: 'threeWayMatching', sortable: true}
              ]);
          }
        );
      }
    }
  }

  tabChange(id: number) {
    this.isShow = id === 2;
    if (!this.isShow) {
    }
  }

  prpareFields(isPODetail: boolean, data: any) {
    this.headerFields = [];
    this.isPODetails = isPODetail;

    this.formData.forEach(function(item) {
      // console.log(data[item.name]);
      console.log('Item Name : ' + item);
      if (data.hasOwnProperty(item.name)) {
         item.value = data[item.name];
         if (item.name === 'threeWayMatchingStatus' || item.name === 'requestor' || item.name === 'paymentTerms') {
            item.visibility = isPODetail;
         }
      }
  });

  }
  prpareGrid(isTaskStatus: boolean, response: any, length: number) {
    this.detail = response;
    }

  setRequesterList() {
    this.costCenterList = [
      {
        id: 'FIC2210',
        name: 'FCS'
      },
      {
        id: 'HRC1880',
        name: 'CC'
      },
      {
        id: 'HRC2780',
        name: 'LCD'
      },
      {
        id: 'HRC6110',
        name: 'SEZ'
      },
      {
        id: 'RND3210',
        name: 'R&D'
      }
    ];
    this.glCodeList = [
      {
        id: '100581',
        name: '100581'
      },
      {
        id: '100583',
        name: '100583'
      },
      {
        id: '100585',
        name: '100585'
      },
      {
        id: '100600',
        name: '100600'
      },
      {
        id: '100743',
        name: '100743'
      }
    ];
  }

  onPOChange($event, id: string) {
    if (id === 'poNumber') {
      this.data.poNumber = $event.target.value;
      this.onDataLoaded.emit(this.data);
    }

  }

  onRequesterChange($event) {
    console.log(' Req event : ' + $event);
    this.data.requester = $event.value;
    this.data.inboundInvoiceDocId = this.inboundInvoiceDocId;
    this.onDataLoaded.emit(this.data);
  }

  onSelectBoxChange() {
    this.data.lineDetails = this.lineItemDetails;
    this.onDataLoaded.emit(this.data);
  }

  changeSizeItemDetailPagi(event: Pagination): void {
    this.lineItemDetailsPagination = {count: event.maxItems, totalItems: event.totalItems, skipCount: 0, maxItems: event.maxItems , hasMoreItems: true};
    this.processPageDetailPagination( this.lineItemDetailsPagination );
  }

  processPageDetailPagination(event: Pagination) {
    let noOfStep = 0;
    if ( event.skipCount !== 0) {
      noOfStep =  event.skipCount /  event.count;
    }

    this.lineItemDetailsPagination = {
            count: event.maxItems,
            totalItems: event.totalItems,
            skipCount: event.skipCount,
            maxItems: event.maxItems,
            hasMoreItems: this.isNextPagination(noOfStep, event.totalItems, event.count)
          };
    (event.skipCount === 0) ? this.bankDetailsPaginatination(noOfStep, event.count, false) : this.bankDetailsPaginatination(noOfStep, event.count, false);

  }

  private isNextPagination(noOfStep: number, totalItem: number, count: number): boolean {
    return ((++noOfStep) * count) < totalItem;
  }

  bankDetailsPaginatination(offset: number, limit: number, isDefaultCall: boolean) {
    let bankDetailsPaginationData = this.invoiceService.getInvoiceBankDetailsByInvoiceNo(this.invoiceNumber, ++offset, limit);
    if (bankDetailsPaginationData !== null) {
      bankDetailsPaginationData.subscribe((data: any) => {
        let bankDetailsStore = data.pageItems;
        if (isDefaultCall) {
          this.lineItemDetailsPagination = {count: this.PERPAGEITEMSIZE, totalItems: data.totalRecords, skipCount: 0, maxItems: 5 , hasMoreItems: true};
        }
        this.bankDetailInit(bankDetailsStore);
      }, (error: any) => {
        console.error('Error is there =>', error);
    });
   }
  }

  tabChanged(event: any) {
    if (event.index === 2) {
      console.log('Index : ' + event.index);
      this.invoiceService.getVenderBankDetailsByVendorCode(this.vendorCode).subscribe((res: any) => {
        this.vendorCodeDetails = [res];
        console.log('Data : ' + JSON.stringify(this.vendorCode));
        this.vendorDetails = new ObjectDataTableAdapter(this.vendorCodeDetails,
          [
            {type: 'text', key: 'bankName', title: 'Bank Name', sortable: true},
            {type: 'text', key: 'beneficary', title: 'Beneficiary', sortable: true},
            {type: 'text', key: 'accountNo', title: 'Account No', sortable: true},
            {type: 'text', key: 'swift', title: 'Swift', sortable: true},
            {type: 'text', key: 'iban', title: 'Iban', sortable: true},
            {type: 'text', key: 'currType', title: 'Currency', sortable: true}
          ]
        );

      }, (error: any) => {
        console.error('Error is there =>', error);
      });
    }
  }

  bankDetailInit(bankDetailsPagination: any) {
    this.bankDetails = new ObjectDataTableAdapter(bankDetailsPagination,
      [
        {type: 'text', key: 'bankName', title: 'Bank Name', sortable: true},
        {type: 'text', key: 'beneficary', title: 'Beneficiary', sortable: true},
        {type: 'text', key: 'accountNo', title: 'Account No', sortable: true},
        {type: 'text', key: 'swift', title: 'Swift', sortable: true},
        {type: 'text', key: 'iban', title: 'Iban', sortable: true},
        {type: 'text', key: 'currType', title: 'Currency', sortable: true}
      ]
    );
  }

}

  // Muraai group ends

export class MuraaiField {
  constructor(
    private isVisible: boolean,
    private id: string,
    private label: string,
    private key: string,
    private type: string,
    private readonly: boolean,
    private widthClass: string
  ) { }
}
export class MuraaiGrid {
  constructor(
    private isVisible: boolean,
    private header: string,
    public key: string
  ) { }
}
