/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit } from '@angular/core';
import { Pagination } from 'alfresco-js-api';
import { GroupMasterService } from './services/group-master.service';
import { PageEvent } from '@angular/material';
import { EntityMasterModel } from '../../models/entity-master.model';
import { FieldDetails } from '../../models/mu-field.model';

@Component({
    selector: 'group-master',
    templateUrl: './group-master.component.html',
    styleUrls: ['./group-master.component.scss'],
    providers: [GroupMasterService]
})
export class GroupMasterComponent implements OnInit {
    PERPAGEITEMSIZE: number = 5;
    detailsPagination: Pagination;
    searchData = {};
    formData: FieldDetails<any>[];
    entityMasterModel: EntityMasterModel;
    deletedRecord = [];
    statusMasterList = [];
    isSearch: boolean = false;
    getAllGroupData = [];
    pageEvent: PageEvent;
    mutltiSelect: boolean = false; // this property for enabled checkBox for select
    header = 'Group Master';
    showPagination: boolean = true;
    searchFormFiled: FieldDetails<any>[] = [
        {
            label: 'Group Name',
            id: 'groupDesc',
            name: 'groupDesc',
            type: 'text',
            visibility: true,
            controlType: 'textbox',
            placeholder: 'Enter Group Name',
            disabled: false,
            cssClass: 'mu-inputField',
            width: 6,
            value: null
        },
        {
            name: 'Search',
            type: 'submit',
            controlType: 'button'
        },
        {
            name: 'Close',
            type: 'button',
            controlType: 'button'
        }
    ];
    constructor(private groupMastersService: GroupMasterService) {

    }
    ngOnInit() {
        this.getAllStatusMasters();
        this.getAllGroup(0, this.PERPAGEITEMSIZE, true, true, ''); // this method call when page load to get entity master data
    }
    getAllGroup(offset: number, limit: number, isDefaultCall: boolean, isNotSearchCall: boolean, searchText: any) {
        this.groupMastersService.getAllGroupMaster(offset, limit, this.searchData).subscribe((res: any) => {
            this.getAllGroupData = res.content;
            this.showPagination = true;
            if (this.getAllGroupData.length === 0) { // this for pagination will be hide when no data
                this.showPagination = false;
            }
            if (isDefaultCall) {
                if (res.totalElements > this.PERPAGEITEMSIZE) {
                    this.detailsPagination = { count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: 10, hasMoreItems: true };
                } else {
                    this.detailsPagination = { count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: 10, hasMoreItems: false };
                }
            }
        });
    }
    public onSearchResponse(event): void {
        if (event.groupDesc !== undefined) {
            this.searchData = event;
        } else {
            this.searchData = { 'param': event };
        }
        this.getAllGroup(0, this.PERPAGEITEMSIZE, true, true, '');
    }
    processDetailPagination(event: Pagination): void { //  this method call when user click  left or right arror of pagination
        let noOfStep = 0;
        if (event.skipCount !== 0) {
            noOfStep = event.skipCount / event.count;
        }
        this.detailsPagination = {
            count: event.maxItems,
            totalItems: event.totalItems,
            skipCount: event.skipCount,
            maxItems: event.maxItems,
            hasMoreItems: this.isNextPagination(noOfStep, event.totalItems, event.count)
        };
        if (event.maxItems > event.totalItems) {
            this.getAllGroup(0, event.totalItems, false, true, '');
        } else {
            this.getAllGroup(this.detailsPagination.skipCount / this.detailsPagination.maxItems, event.maxItems, false, true, '');
        }
    }

    changeSizeItemDetailPagi(event: Pagination): void {
        this.detailsPagination = { count: event.maxItems, totalItems: event.totalItems, skipCount: 0, maxItems: event.maxItems, hasMoreItems: true };
        this.processDetailPagination(this.detailsPagination);
    }
    private isNextPagination(noOfStep: number, totalItem: number, count: number): boolean {
        return ((++noOfStep) * count) < totalItem;
    }
    getAllStatusMasters() {
        this.groupMastersService.getAllStatusMaster().subscribe((res: any) => {
            this.statusMasterList = res;
        }, (err) => {
            console.log(JSON.stringify(err));
        });

    }
}
