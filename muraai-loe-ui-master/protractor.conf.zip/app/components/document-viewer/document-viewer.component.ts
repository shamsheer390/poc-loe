/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, Input, SimpleChanges} from '@angular/core';
import { InvoiceUploadService } from '../../services/index';

declare var componentHandler;
declare let dialogPolyfill: any;
declare var document: any;

@Component({
  selector: 'adf-document-viewer',
  templateUrl: './document-viewer.component.html',
  styleUrls: ['./document-viewer.component.css'],
  providers: [InvoiceUploadService]
})
export class ADFDocuemntViewerComponent {

  @Input()
  invoiceNumber: string = '';

  fileNodeId: string = '';

  constructor(private viewerService: InvoiceUploadService) {

  }

  ngOnChanges(changes: SimpleChanges) {
    let invoiceNumberObj = changes['invoiceNumber'];
    if (invoiceNumberObj) {
      if (invoiceNumberObj.currentValue) {
        this.viewerService.getDocDetails(this.invoiceNumber).subscribe(
          (response) => {
            if (response.docsRef === '' || response.docsRef === null || response.docsRef === undefined) {
              this.fileNodeId = 'a6da437c-eb14-4cfa-8993-005e1a4b9bc6';
            } else {
              this.fileNodeId = response.docsRef;
            }
          }
        );
      }
    }
  }
}
