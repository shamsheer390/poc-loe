/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit, Input } from '@angular/core';
import { ObjectDataTableAdapter } from 'ng2-alfresco-datatable';
import { InvoiceSummaryService } from './services/invoice-summary.service';
import { InvoiceSummaryDetails } from '../../models/invoice-summary.model';
import { Pagination } from 'alfresco-js-api';
import {AlfrescoTranslationService} from 'ng2-alfresco-core';
import { Router } from '@angular/router';
import { FieldDetails } from 'app/models/mu-field.model';

@Component({
  selector: 'invoice-summary',
  templateUrl: './invoice-summary.component.html',
  providers: [InvoiceSummaryService],
  styleUrls: ['./invoice-summary.component.scss']
})
export class InvoiceSummaryComponent implements OnInit {

  searchFieldData: FieldDetails<any>[]= [
    {
      label: 'Invoice Number',
      id: 'invoiceNo',
      name: 'invoiceNo',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter invoice number',
      disabled: false,
      validation: [],
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'PO Number',
      id: 'poNumber',
      name: 'poNumber',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter po number',
      disabled: false,
      validation: [],
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Invoice Status',
      id: 'invoiceStatus',
      name: 'invoiceStatus',
      type: 'select',
      controlType: 'selectbox',
      placeholder: 'Select invoice status',
      options: ['Clarification Provided', 'GL Code and Cost Centre Mapped', 'Invoice Approved', 'Invoice Data Extracted', 'Invoice Rejected'],
      validation: [],
      disabled: false,
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Vendor',
      id: 'vendor',
      name: 'vendor',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter vendor name',
      disabled: false,
      validation: [],
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Invoice From Date',
      id: 'invoiceFromDate',
      name: 'invoiceFromDate',
      type: 'date',
      controlType: 'datepicker',
      placeholder: 'Enter from date',
      disabled: false,
      validation: [],
      cssClass: 'mu-inputField',
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Invoice To Date',
      id: 'invoiceToDate',
      name: 'invoiceToDate',
      type: 'date',
      controlType: 'datepicker',
      placeholder: 'Enter to date',
      disabled: false,
      validation: [],
      width: 3,
      value: null,
      visibility: true
    },
    {
      label: 'Entity name',
      id: 'entityName',
      name: 'entityName',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter entity name',
      disabled: false,
      validation: [],
      width: 3,
      value: null,
      visibility: true
    },
    {
      name: 'Search',
      type: 'submit',
      controlType: 'button'
    },
    {
      name: 'Refresh',
      type: 'button',
      controlType: 'button'
    }
  ];

  data: ObjectDataTableAdapter;

  @Input()
  invoiceSummary: InvoiceSummaryDetails = new InvoiceSummaryDetails();

  invoiceSummarys: Array<any>;
  PERPAGEITEMSIZE: number = 5;
  detailsPagination: Pagination;
  isSearch: boolean = false;
  searchData = {'param' : 'm'};

  constructor( private invoiceService: InvoiceSummaryService, private translateService: AlfrescoTranslationService, private router: Router) {
    if (translateService) {
        translateService.addTranslationFolder('Muraai', '/custom-translation/invoice-summary');
    }
  }

  ngOnInit() {
    this.searchData = {'param' : 'm'};
    this.getAllInvoiceSummary(true, '');
  }

  getAllInvoiceSummary(isNotSearchCall, searchData ) {
    this.summeryDetailsPaginatination(0, this.PERPAGEITEMSIZE, true, isNotSearchCall, this.searchData);
  }

  public onSearchResponse(event): void {
    if ( event.invoiceNo !== undefined) {
      this.searchData = event;
    }else {
      this.searchData = {'param': event};
    }
    this.getAllInvoiceSummary(false, this.searchData);
  }

  public onRefresh(event): void {
    if (event) {
      this.searchFieldData.forEach(function(item) {
           item.value = null;
        });
      console.log('refreshed');
    }
  }

  public processDetailPagination(event: Pagination) {
    let noOfStep = 0;
    if ( event.skipCount !== 0) {
      noOfStep =  event.skipCount /  event.count;
    }
    this.detailsPagination = {
      count: event.maxItems,
      totalItems: event.totalItems,
      skipCount: event.skipCount,
      maxItems: event.maxItems,
      hasMoreItems: this.isNextPagination(noOfStep, event.totalItems, event.count)
    };
    if (event.maxItems > event.totalItems) {
      this.summeryDetailsPaginatination(0, event.totalItems, false, true, '');
    } else {
      this.summeryDetailsPaginatination(this.detailsPagination.skipCount / event.maxItems, event.maxItems, false, true, '');
      }
    }

  public changeNoOfRecordPagination(event: Pagination) {
    this.detailsPagination = {count: event.maxItems, totalItems: event.totalItems, skipCount: 0, maxItems: event.maxItems , hasMoreItems: true};
    this.processDetailPagination( this.detailsPagination );
  }

  public onRowDblClick(event): void {
    this.router.navigate(['/ap/invoice-summary', event.value.obj.invoiceHeaderId, event.value.obj.invoiceNo]);
  }

  private summeryDetailsPaginatination(offset: number, limit: number, isDefaultCall: boolean, isNotSearchCall: boolean, searchText: any) {
    this.invoiceSummarys = [];
    let getInvoice = this.invoiceService.getInvoiceSummarySearch(offset, limit, this.searchData);
    getInvoice.subscribe(
      (res: any) => {
        this.invoiceSummarys = res.content;
        if (isDefaultCall) {
          if (res.totalElements > this.PERPAGEITEMSIZE) {
            this.detailsPagination = {count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: 5 , hasMoreItems: true};
          } else {
            this.detailsPagination = {count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: 5 , hasMoreItems: false};
          }
        }
        this.data = new ObjectDataTableAdapter(this.invoiceSummarys,
          [
            {type: 'text', key: 'invoiceNo', title: 'Invoice No', sortable: true},
            {type: 'text', key: 'invoiceType', title: 'Invoice Type', sortable: true},
            {type: 'date', key: 'invoiceDate', title: 'Invoice Date', sortable: true},
            {type: 'text', key: 'vendorName', title: 'Vendor Name', sortable: true},
            {type: 'text', key: 'vendorCode', title: 'Vendor Code', sortable: true},
            {type: 'text', key: 'poNumber', title: 'PO Number', sortable: true},
            {type: 'text', key: 'invoiceValue', title: 'Invoice Value', sortable: true},
            {type: 'text', key: 'invoiceStatus', title: 'Invoice Status', sortable: true},
            {type: 'text', key: 'errorDescription', title: 'Error Description', sortable: true},
            {type: 'text', key: 'entityCode', title: 'Entity Code', sortable: true},
            {type: 'text', key: 'entityName', title: 'Entity Name', sortable: true}
          ]);
        this.isSearch = !isNotSearchCall;
      },

      (err) => {
        this.data = new ObjectDataTableAdapter(this.invoiceSummarys,
          [
            {type: 'text', key: 'invoiceNo', title: 'Invoice No', sortable: true},
            {type: 'text', key: 'invoiceType', title: 'Invoice Type', sortable: true},
            {type: 'text', key: 'invoiceDate', title: 'Invoice Date', sortable: true},
            {type: 'text', key: 'vendorName', title: 'Vendor Name', sortable: true},
            {type: 'text', key: 'vendorCode', title: 'Vendor Code', sortable: true},
            {type: 'text', key: 'poNumber', title: 'PO Number', sortable: true},
            {type: 'text', key: 'invoiceValue', title: 'Invoice Value', sortable: true},
            {type: 'text', key: 'invoiceStatus', title: 'Invoice Status', sortable: true},
            {type: 'text', key: 'errorDescription', title: 'Error Description', sortable: true},
            {type: 'text', key: 'entityCode', title: 'Entity Code', sortable: true},
            {type: 'text', key: 'entityName', title: 'Entity Name', sortable: true}
          ]);
        if (JSON.parse(err._body).messageCode === '101') {}
      });
  }

  private isNextPagination(noOfStep: number, totalItem: number, count: number): boolean {
    return ((++noOfStep) * count) < totalItem;
  }

}
