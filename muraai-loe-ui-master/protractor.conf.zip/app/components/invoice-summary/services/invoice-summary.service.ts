/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Injectable, EventEmitter, Output} from '@angular/core';
import {Http} from '@angular/http';
import { MuraaiHttpCoreServices } from '../../core/muraai-http-core-services';
@Injectable()
export class InvoiceSummaryService {

  @Output()
  dataLimit: EventEmitter<any> = new EventEmitter<any>();

  constructor(private http: Http, private muraaiHttpCoreServices: MuraaiHttpCoreServices) {
  }

  getInvoiceSummarySearch(page , size , searchObj: any): any {
    let url = 'rest/services/searchInvoices?' + 'page=' + page + '&size=' + size ;
    let body = JSON.stringify(searchObj);
    return this.muraaiHttpCoreServices.httpPost(url, body);
  }

  getInvoiceHeaderByInvoiceHeaderId(invoiceHeaderId: number): any {
    let url = 'rest/services/getInvoiceHeaderByInvoiceHeaderId?invoiceHeaderId=' + invoiceHeaderId;
    return this.muraaiHttpCoreServices.httpGet(url);
  }

  getInvoiceDetailsByInvoiceHeaderId(invoiceHeaderId: number): any {
    let url = '/rest/services/getInvoiceDetailsByInvoiceHeaderId?invoiceHeaderId=' + invoiceHeaderId;
    return this.muraaiHttpCoreServices.httpGet(url);
  }

  getThreeWayDetailsByInvoiceHeaderId(invoiceHeaderId: number): any {
    let url = '/rest/services/getThreeWayMatchingDetailsByInvoiceHeaderId?invoiceHeaderId=' + invoiceHeaderId;
    return this.muraaiHttpCoreServices.httpGet(url);
  }

  getAllInvoiceBankDetailsByInvoiceNo(invoiceNumber: number): any {
    return null;
  }

  getInvoiceBankDetailsByInvoiceNo(invoiceNumber: number, offset: number, limit: number): any {
    return null;
  }

  getVenderBankDetailsByVendorCode(vendorCode: number): any {
    let url = '/rest/services/getVendorBankDetailsbyVendorId?vendorCode=' + vendorCode;
    return this.muraaiHttpCoreServices.httpGet(url);
  }

}
