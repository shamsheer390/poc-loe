/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {ObjectDataTableAdapter} from 'ng2-alfresco-datatable';
import {BatchserviceService} from './services/batchservice.service';
import {Batch} from '../../models/batch.model';
import {MdDialog} from '@angular/material';
import {DialogComponent} from './dialog.component';

@Component({
  selector: 'app-documentstatus',
  templateUrl: './dataextractionstatus.component.html',
  styleUrls: ['./dataextractionstatus.component.css'],
  providers: [BatchserviceService],
  encapsulation: ViewEncapsulation.Emulated
})
export class DataExtractionStatusComponent implements OnInit {

  data: ObjectDataTableAdapter;
  batch: Batch[];           // for response model data

  constructor(private batchservice: BatchserviceService, public dialog: MdDialog) {
  }

  ngOnInit() {
    this.getDataset();
  }

  getDataset() {
    this.batchservice.getAllActiveBatch().subscribe(
      (res) => {
        this.batch = Batch.fromJsonList(res);
        this.createTable(this.batch);
      },
      (err) => {
      }
    );
  }

  createTable(data) {
    this.data = new ObjectDataTableAdapter(
      data,
      [
        {
          type: 'text',
          key: 'id',
          title: 'Id',
          sortable: true
        },
        {
          type: 'text',
          key: 'fileName',
          title: 'FileName',
          sortable: true
        },
        {
          type: 'text',
          key: 'status',
          title: 'Status',
          sortable: true
        }
      ]
    );
  }

  // Row click Event
  onRowClick(event) {
    this.dialog.open(DialogComponent, {
      data: event.value.obj,
      height: '410px',
      width: '700px'
    });
  }

}
