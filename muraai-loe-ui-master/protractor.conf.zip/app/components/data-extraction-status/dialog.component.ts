/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Component, Inject} from '@angular/core';
import {MD_DIALOG_DATA} from '@angular/material';
import {MdDialog} from '@angular/material';

@Component({
  selector: 'your-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})

export class DialogComponent {

  value: number;            // for progress value
  progressclass: string;    // for progress color class
  progressvalue: number;

  constructor(@Inject(MD_DIALOG_DATA) public data: any, public dialog: MdDialog) {
    this.Progressbarchange(this.data.status);
  }

  // for porgress bar creation
  creatprogrssbar(color: string, size: number) {
    this.value = size;
    this.progressvalue = size;
    if (color === 'warn') {
      this.progressclass = 'skill-2';
      this.progressvalue = 0;
    } else if (color === 'primary') {
      this.progressclass = 'skill-1';
    }
  }

  // selecting progress bar
  Progressbarchange(type: string) {
    // primary  - blue
    // warn -red
    // accent -purple
    if (type === 'NEW') {
      this.creatprogrssbar('primary', 20);
    } else if (type === 'READY_FOR_REVIEW') {
      this.creatprogrssbar('primary', 40);
    } else if (type === 'READY_FOR_VALIDATION') {
      this.creatprogrssbar('primary', 60);
    } else if (type === 'READY') {
      this.creatprogrssbar('primary', 80);
    } else if (type === 'FINISHED') {
      this.creatprogrssbar('primary', 100);
    } else if (type === 'ERROR') {
      this.creatprogrssbar('warn', 100);
    }
  }

  closeAll() {
    this.dialog.closeAll();
  }
}
