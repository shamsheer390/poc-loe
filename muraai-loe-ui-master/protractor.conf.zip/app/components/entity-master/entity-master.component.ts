/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Pagination } from 'alfresco-js-api';
import { EntityMasterService } from './services/entity-master.service';
import { PageEvent } from '@angular/material';
import { EntityMasterModel } from '../../models/entity-master.model';
import { FieldDetails } from '../../models/mu-field.model';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
@Component({
    selector: 'entity-master',
    templateUrl: './entity-master.component.html',
    styleUrls: ['./entity-master.component.scss'],
    providers: [EntityMasterService]
})
export class EntityMasterComponent implements OnInit {
    PERPAGEITEMSIZE: number = 5;
    selectionMode: string = 'none';
    detailsPagination: Pagination;
    entityMasterModel: EntityMasterModel;
    formData: FieldDetails<any>[];
    deletedRecord = [];
    statusMasterList = [];
    updatedEntityValue = [];
    copyOfAllEntityData = [];
    newAddedRecords: EntityMasterModel[];
    searchData = {};
    isSearch: boolean = false;
    getAllEntityData = [];
    showAdd: boolean = true;
    showRemove: boolean = true;
    pageEvent: PageEvent;
    mutltiSelect: boolean = true; // this property for enabled checkBox for select
    header = 'Entity Master';
    showPagination: boolean = true;
    showSave: boolean = true;
    searchFormField: FieldDetails<any>[] = [
        {
            label: 'Entity Name',
            id: 'entityName',
            name: 'entityName',
            type: 'text',
            controlType: 'textbox',
            placeholder: 'Enter Entity Name',
            disabled: false,
            visibility: true,
            cssClass: 'mu-inputField',
            width: 6,
            value: null
        },
        {
            label: 'Entity Code',
            id: 'entityCode',
            name: 'entityCode',
            type: 'text',
            controlType: 'textbox',
            visibility: true,
            placeholder: 'Enter Entity Code',
            disabled: false,
            cssClass: 'mu-inputField',
            width: 6,
            value: null
        },
        {
            name: 'Search',
            type: 'submit',
            controlType: 'button'
        },
        {
            name: 'Close',
            type: 'button',
            controlType: 'button'
        }
    ];
    constructor(private entityMastersService: EntityMasterService, public toastr: ToastsManager, vcr: ViewContainerRef) {
        this.toastr.setRootViewContainerRef(vcr);
    }
    ngOnInit() {
        this.getAllStatusMasters();
        this.getAllEntity(0, this.PERPAGEITEMSIZE, true, true, ''); // this method call when page load to get entity master data
    }
    getAllEntity(offset: number, limit: number, isDefaultCall: boolean, isNotSearchCall: boolean, searchText: any) {
        this.entityMastersService.getAllEntityMaster(offset, limit, this.searchData).subscribe((res: any) => {
            this.getAllEntityData = res.content;
            this.showPagination = true;
            if (this.getAllEntityData.length === 0) { // this for pagination will be hide when no data
                this.showPagination = false;
            }
            this.copyOfAllEntityData = JSON.parse(JSON.stringify(res.content));
            if (isDefaultCall) {
                if (res.totalElements > this.PERPAGEITEMSIZE) {
                    this.detailsPagination = { count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: 5, hasMoreItems: true };
                } else {
                    this.detailsPagination = { count: this.PERPAGEITEMSIZE, totalItems: res.totalElements, skipCount: 0, maxItems: 5, hasMoreItems: false };
                }
            }
        });
    }
    onAdd(data) {
        this.entityMasterModel = new EntityMasterModel();
        this.getAllEntityData.unshift(this.entityMasterModel);
    }
    onDelete(result): void {// this method for delete the single entity or multiple entity
        this.deletedRecord = [];
        if (result.length > 0) {
            result.forEach(element => {
                if (element.entityId !== null) {
                    this.deletedRecord.push(element.entityId);
                }
            });
            if (this.deletedRecord.length > 0) { // deletedRecord Length > 0 then service will call
                this.entityMastersService.deleteEntity(this.deletedRecord).subscribe((res: any) => {
                    this.getAllEntityData = this.getAllEntityData.filter(function (el) {
                        return result.indexOf(el) < 0;
                    });
                }, (err) => {
                    console.log(JSON.stringify(err));
                });
            } else {
                this.toastr.success('Successfully Deleted', 'Success!');
                this.getAllEntityData = this.getAllEntityData.filter(function (el) {
                    return result.indexOf(el) < 0;
                });
            }
        }
    }
    processDetailPagination(event: Pagination): void { //  this method call when user click  left or right arror of pagination
        let noOfStep = 0;
        console.log(event);
        if (event.skipCount !== 0) {
            noOfStep = event.skipCount / event.count;
        }
        this.detailsPagination = {
            count: event.maxItems,
            totalItems: event.totalItems,
            skipCount: event.skipCount,
            maxItems: event.maxItems,
            hasMoreItems: this.isNextPagination(noOfStep, event.totalItems, event.count)
        };
        if (event.maxItems > event.totalItems) {
            this.getAllEntity(0, event.totalItems, false, true, '');
        } else {
            this.getAllEntity(this.detailsPagination.skipCount / event.maxItems, event.maxItems, false, true, '');
        }
    }

    changeSizeItemDetailPagi(event: Pagination): void {
        this.detailsPagination = { count: event.maxItems, totalItems: event.totalItems, skipCount: 0, maxItems: event.maxItems, hasMoreItems: true };
        this.processDetailPagination(this.detailsPagination);
    }
    private isNextPagination(noOfStep: number, totalItem: number, count: number): boolean {
        return ((++noOfStep) * count) < totalItem;
    }
    public onSearchResponse(event): void {
        if (event.entityCode !== undefined) {
            this.searchData = event;
        } else {
            this.searchData = { 'param': event };
        }
        this.getAllEntity(0, this.PERPAGEITEMSIZE, true, true, '');
    }
    getAllStatusMasters() {
        this.entityMastersService.getAllStatusMaster().subscribe((res: any) => {
            this.statusMasterList = res;
        }, (err) => {
            console.log(JSON.stringify(err));
        });

    }
    saveAllEntity(event) {
        this.updatedEntityValue = [];
        this.newAddedRecords = [];
        this.newAddedRecords = event.filter(item => (item.entityId === null));
        event = event.filter(item => (item.entityId !== null));
        for (let i = 0; i < event.length; i++) { // when object property changed this for update case In service send only updated object
            let row = this.copyOfAllEntityData[i];
            if (event[i].entityCode !== row.entityCode || event[i].entityName !== row.entityName
                || event[i].status !== row.status) {
                this.updatedEntityValue.push(event[i]);
            }
        }
        this.updatedEntityValue = this.updatedEntityValue.concat(this.newAddedRecords);
        this.entityMastersService.saveEntity(this.updatedEntityValue).subscribe((res: any) => {
            this.toastr.success('Successfully Saved', 'Success!');
            this.getAllEntity(0, this.PERPAGEITEMSIZE, true, true, '');
        }, (err: any) => {
        });
    }
}
