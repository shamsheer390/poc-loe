/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit} from '@angular/core';
import {DashBoardService} from '../../services/dashboard.service';

@Component({
  selector: 'chart-dashboard',
  templateUrl: './chart-dashboard.component.html',
  styleUrls: ['./chart-dashboard.component.css'],
  providers: [DashBoardService]
})
export class ChartDashboard implements OnInit {

  static TABWISELIST: any = [ {'id': 0 , 'name' : 'VENDER-WISE' }, {'id': 1 , 'name' : 'STATUS-WISE' }, {'id': 2 , 'name' : 'YEARLY' } ];
  test: boolean = false ;
  isDefault: boolean = true ;
  isMonthly: boolean = false ;
  isShowStatusWise: boolean = false ;
  isClosePieChart: boolean = false ;
  isStatusLineChartDetails: boolean = false;
  ismonthlyVenderPieChartDetails: boolean = false;

  venderName: string = '' ;
  clickedMonth: string = '' ;
  formattedVendorLabel: string = '';

  trimmedBarChartData: Array <any> = [];

  public selectedVenderName = '' ;

  public pieChartLabel: string[] = [];
  public pieChartData: number[] = [];

  public barChartLabels: string[] = [];
  public barChartData: any[] = [];

  public yearlyBarChartLabels: string[] = [];
  public yearlyBarChartData: any[] = [];

  public venderStatusLineChartLabels: string[] = [];
  public venderStatusLineChartData: any[] = [];

  public monthlyVenderPieChartLabels: string[] = [];
  public monthlyVenderPieChartData: any[] = [];

  constructor(private dashBoardService: DashBoardService) {}

  ngOnInit() {
    this.venderWiseDetails();
  }

  public tabChanged(e: any): void {
    for ( let i = 0; i < ChartDashboard.TABWISELIST.length; i++) {
      if ( ChartDashboard.TABWISELIST[i]['id'] === e.index ) {
        switch (ChartDashboard.TABWISELIST[i]['id']) {
          case 0: this.venderWiseDetails();
            break;
          case 1:
            this.statusWiseDetails();
            break;
          case 2:
            this.isDefault = true ;
            this.isMonthly = false ;
            this.isShowStatusWise = false ;
            this.isClosePieChart = false ;
            this.annualDetails();
            break;
          default: console.log('');
        }
        break;
      }
    }
  }

  public venderWiseDetails(): void {

    let pieChartLable: string[] = [];
    let pieChartData: number[] = [];

    this.dashBoardService.getVenderWiseDetails().subscribe(
      (result: any) => {
        if (result) {
          for ( let i = 0; i < result.length; i++) {
            pieChartLable.push(result[i]['venderName'] ? result[i]['venderName'].toUpperCase() : result[i]['venderName']);
            pieChartData.push(+result[i]['invoiceAmount']);
          }
        }
        this.pieChartLabel = pieChartLable;
        this.pieChartData = pieChartData;

      }, (error: any) => {
        console.log('exception found in venderWiseDetails()', error);
      }
    );
  }

  public statusWiseDetails(): void {
    this.dashBoardService.getStatusWiseDetails().subscribe(
      res => {
        let _barChartLabels: string[] = [];
        let _barChartData: string[] = [];
        for ( let i = 0 ; i < res.length ; i++ ) {
          _barChartLabels.push(res[i]['invoiceStatus']);
          _barChartData.push(res[i]['noOfInvoice']);
        }
        this.barChartLabels = _barChartLabels;
        this.barChartData = [{'data' : _barChartData, 'label': 'Status Data'}];
      },
      error => {
        console.log('exception found in statusWiseDetails()', error) ;
      }
    );
  }

  public annualDetails(): void {
    this.dashBoardService.getVenderAnnualDetails().subscribe(
      res => {
        let labelLength = 15 ;
        let trimmedLabel: string = '' ;
        let _yearlyBarChartLabels: string[] = [];
        let _yearlyBarChartData: string[] = [];

        for ( let i = 0 ; i < res.length ; i++ ) {
          trimmedLabel = '' ;
          trimmedLabel = (res[i]['vendorName'].length > labelLength) ? res[i]['vendorName'].substring(0, labelLength) + '...' : res[i]['vendorName'] ;
          trimmedLabel.toUpperCase();
          this.trimmedBarChartData.push({'label': res[i]['vendorName'] , 'trimmedLabel': trimmedLabel, 'vendorId': res[i]['vendorId']});

          _yearlyBarChartLabels.push(trimmedLabel);
          _yearlyBarChartData.push(res[i]['invoiceAmount']);
        }

        this.yearlyBarChartLabels = _yearlyBarChartLabels;
        this.yearlyBarChartData = [{'data' : _yearlyBarChartData, 'label': 'Yearly Data'}];
      },
      error => {
        console.log('exception found in annualDetails()', error) ;
      }
    );
  }

  public monthlyVenderPieChartDetails(vender: string): void {
    this.monthlyVenderPieChartLabels = [];
    this.monthlyVenderPieChartData = [];
    this.ismonthlyVenderPieChartDetails = false;
    if ( !(vender === null || vender === '') ) {
      for  (let i = 0 ; i < this.trimmedBarChartData.length ; i++) {
        if ( this.trimmedBarChartData[i]['trimmedLabel'] === vender ) {
          this.formattedVendorLabel = this.trimmedBarChartData[i]['label'].split(' ').join('_');
          this.venderName = this.trimmedBarChartData[i]['label'] ;
          break ;
        }
      }

      this.dashBoardService.getVenderMonthlyDetails(this.formattedVendorLabel).subscribe(
        res => {
          let _monthlyVenderPieChartLabels: string[] = [];
          let _monthlyVenderPieChartData: string[] = [];

          for ( let i = 0 ; i < res.length ; i++ ) {
            _monthlyVenderPieChartLabels.push(res[i]['nameOfMonth']);
            _monthlyVenderPieChartData.push(res[i]['invoiceAmount']);
          }
          this.ismonthlyVenderPieChartDetails = true;
          this.monthlyVenderPieChartLabels = _monthlyVenderPieChartLabels;
          this.monthlyVenderPieChartData = _monthlyVenderPieChartData;
          this.selectedVenderName = this.venderName ;
        },
        error => {
          console.log('exception found in monthlyVenderPieChartDetails()', error) ;
        }
      ) ;
    }

  }

  public venderStatusLineChartDetails(vender: string, month: string): void {
    this.isStatusLineChartDetails = false;
    this.venderStatusLineChartLabels = [];
    this.venderStatusLineChartData = [];

    if (!( month === null || month === '')) {

      this.dashBoardService.getVenderMonthlyInvoiceDetails(vender, month ).subscribe(
        res => {
          let _venderStatusLineChartLabels: string[] = [];
          let _venderStatusLineChartData: string[] = [];

          for ( let i = 0 ; i < res.length ; i++ ) {
            _venderStatusLineChartLabels.push(res[i]['status']);
            _venderStatusLineChartData.push(res[i]['noOfInvoice']);
          }
          this.isStatusLineChartDetails = true;
          this.venderStatusLineChartLabels = _venderStatusLineChartLabels;
          this.venderStatusLineChartData =  [{'data' : _venderStatusLineChartData, 'label': this.clickedMonth}];
        },
        error => {
          console.log('exception found in venderStatusLineChartDetails()', error) ;
        }
      ) ;
    }
  }

  public statusWiseClickCallBack(event: any) {
  }

  public venderWiseClickCallBack(event: any) {
  }

  /**
   * Annual wise respected
   * Call back function
   * When click the chart respected Index related information
   * @param event
   */

  public annualWiseClickCallBack(event: any) {
    this.isDefault = false ;
    this.isShowStatusWise = false ;
    this.isClosePieChart = false ;
    this.isMonthly = true ;

    this.venderName = event.label ;
    this.monthlyVenderPieChartDetails(this.venderName) ;
  }

  public monthlyVenderPieChartClickInfo(event: any) {

    this.clickedMonth = event.label ;

    this.isShowStatusWise = true ;
    this.isDefault = false ;
    this.isMonthly = false ;
    this.isClosePieChart = false ;

    this.venderStatusLineChartDetails(this.formattedVendorLabel, this.clickedMonth) ;
  }

  public venderStatusLineChartClickInfo(event: any) {}

  public closeYearlyPieChart(event: any) {
    if (event && !this.isShowStatusWise) {
      this.isMonthly = false ;
      this.isDefault = true ;

    }else if (event && this.isShowStatusWise) {
      this.isShowStatusWise = false ;
      this.isClosePieChart = true ;

    }
  }

  public closeYearlyLineChart(event: any) {
    if (event && !this.isClosePieChart && this.isShowStatusWise) {
      this.isShowStatusWise = false ;
      this.isMonthly = true ;

    }else if (event && !this.isMonthly && !this.isShowStatusWise) {
      this.isMonthly = false ;
      this.isClosePieChart = false ;
      this.isDefault = true ;
    }
  }

}
