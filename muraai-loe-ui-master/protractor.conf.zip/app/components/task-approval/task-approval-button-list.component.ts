/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, Input, SimpleChanges, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { TaskApprovalService } from './services/task-approval.service';
import { ActivitiTaskListService } from 'ng2-activiti-tasklist';

declare let dialogPolyfill: any;

@Component({
  selector: 'task-approval-button-list',
  moduleId: module.id.toString(),
  templateUrl: './task-approval-button-list.component.html',
  styleUrls: ['./task-approval-button-list.component.css'],
  providers: [TaskApprovalService, ActivitiTaskListService]
})
export class TaskApprovalButtonListComponent {

  @Input()
  taskName: string = '';
  @Input()
  invoiceHeaderId: string = '';
  @Input()
  instanceId: string = '';
  @Input()
  taskId: string = '';

  @Input()
  data: any = {};

  @ViewChild('alertbox')
  alertbox: any;

  taskType: string = '';

  buttonServiceData: any;
  buttonList: Array<any> = [];

  taskStatus: string = '';
  req: string = '';
  constructor(private taskApprovalServices: TaskApprovalService,
              private router: Router,
              private activitiTaskList: ActivitiTaskListService) {
              this.setButtonServiceData();
  }

  ngOnChanges(changes: SimpleChanges) {
    let taskNameObj = changes['taskName'];
    if (taskNameObj) {
      if (taskNameObj.currentValue) {
        this.taskType = taskNameObj.currentValue.split(' - ')[0];
        this.setButtonList(this.taskType);
      }
    }
  }

  private setButtonServiceData() {
    this.buttonServiceData = {
      'Invoice Approval': [{ 'label': 'Approve', 'status': 'approved' }, { 'label': 'Reject', 'status': 'rejected' }],
      'Invoice Approval PO': [{ 'label': 'Approve', 'status': 'Invoice Approved' }, { 'label': 'Reject', 'status': 'Invoice Rejected' }],
      'Invoice Approval Non PO': [{ 'label': 'Approve', 'status': 'Invoice Approved' }, { 'label': 'Reject', 'status': 'Invoice Sent Back to Finance' }],
      'Clarification Required': [{ 'label': 'Submit', 'status': 'Clarification Provided' }, { 'label': 'Send Back', 'status': 'Invoice Sent Back to Vendor' }],
      'Map GL Code and Cost Centre': [{ 'label': 'Submit', 'status': 'GL Code and Cost Centre Mapped' },
       { 'label': 'Send Back', 'status': 'Invoice Sent Back to AP Analysis Team' }],
      'Invoice Validation by Finance': [{ 'label': 'Submit', 'status': 'Invoice Validated by Finance' }, { 'label': 'Send Back', 'status': 'Invoice Sent Back to Requester' }]
    };
  }

  private setButtonList(typeName: string) {
    if (typeName) {
      this.buttonList = this.buttonServiceData['Invoice Approval'];
    }
  }

  ngOnInit() {

  }

  onActionButtonClick(status: string) {
            let instanceId = this.instanceId;
            let invoiceStatusObj = {
              'name': 'clientEmail',
              'type': 'string',
              'value': status,
              'scope': 'global'
            };

            console.log(invoiceStatusObj);
            this.taskApprovalServices.updateInvoiceTaskStatus(invoiceStatusObj, instanceId, 'clientEmail').subscribe(
              () => {
                this.activitiTaskList.completeTask(this.taskId).subscribe(
                  () => {
                    this.showAlert();
                  }
                );
              });
          }

  private showAlert() {

    if (!this.alertbox.nativeElement.showModal) {
      dialogPolyfill.registerDialog(this.alertbox.nativeElement);
    }
    if (this.alertbox) {
      this.alertbox.nativeElement.showModal();
    }
  }

  private closeAlert() {
    if (this.alertbox) {
      this.alertbox.nativeElement.close();
    }

  }

  onOKClick() {
    this.closeAlert();
    this.router.navigate(['/ap/tasks']);
  }
}
