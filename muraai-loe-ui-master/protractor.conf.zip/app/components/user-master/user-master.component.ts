/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit } from '@angular/core';
import { Pagination } from 'alfresco-js-api';
import { UserMasterService } from './services/user-master.service';
import { UserMasterModel } from '../../models/user-master.model';
import { FieldDetails } from '../../models/mu-field.model';

@Component({
    selector: 'user-list',
    templateUrl: './user-master.component.html',
    styleUrls: ['./user-master.component.scss'],
    providers: [UserMasterService]
})
export class UserMasterComponent implements OnInit {
    PERPAGEITEMSIZE: number = 5;
    detailsPagination: Pagination;
    deletedRecord = [];
    formData: FieldDetails<any>[];
    searchData = {};
    statusMasterList = [];
    userMasterModel: UserMasterModel;
    isSearch: boolean = false;
    mutltiSelect: boolean = false; // this property for enabled checkBox for select
    header = 'User Master';
    addHeader = 'Add user';
    editHeader = 'Edit user';
    showPagination: boolean = true;
    getAllUsers = [];
    searchFormField: FieldDetails<any>[] = [
        {
            label: 'First  Name',
            id: 'firstName',
            name: 'firstName',
            visibility: true,
            type: 'text',
            controlType: 'textbox',
            placeholder: 'Enter First Name',
            disabled: false,
            cssClass: 'mu-inputField',
            width: 6,
            value: null
        },
        {
            label: 'Last Name',
            id: 'lastName',
            name: 'lastName',
            type: 'text',
            controlType: 'textbox',
            visibility: true,
            placeholder: 'Enter Last Name',
            disabled: false,
            cssClass: 'mu-inputField',
            width: 6,
            value: null
        },
        {
            label: 'Email',
            id: 'email',
            name: 'email',
            type: 'text',
            visibility: true,
            controlType: 'textbox',
            placeholder: 'Enter Email',
            disabled: false,
            cssClass: 'mu-inputField',
            width: 6,
            value: null
        },
        {
            name: 'Search',
            type: 'submit',
            controlType: 'button'
        },
        {
            name: 'Close',
            type: 'cancel',
            controlType: 'button'
        }
    ];
    constructor(private userMasterService: UserMasterService) { }
    ngOnInit() {
        this.getAllStatusMasters();
        this.getAllUser(0, this.PERPAGEITEMSIZE, true, true, '');
    }
    getAllUser(offset: number, limit: number, isDefaultCall: boolean, isNotSearchCall: boolean, searchText: any) {
        this.userMasterService.getAllUserMaster(offset, limit, this.searchData).subscribe(
            (result: any) => {
                this.getAllUsers = result.content;
                this.showPagination = true;
                if (this.getAllUsers.length === 0) { // this for pagination will be hide when no data
                    this.showPagination = false;
                }
                if (isDefaultCall) {
                    if (result.totalElements > this.PERPAGEITEMSIZE) {
                        this.detailsPagination = {
                            count: this.PERPAGEITEMSIZE, totalItems: result.totalElements, skipCount: 0,
                            maxItems: this.PERPAGEITEMSIZE, hasMoreItems: true
                        };
                    } else {
                        this.detailsPagination = {
                            count: this.PERPAGEITEMSIZE, totalItems: result.totalElements, skipCount: 0,
                            maxItems: this.PERPAGEITEMSIZE, hasMoreItems: false
                        };
                    }
                }
            });
    }

    processDetailPagination(event: Pagination): void { //  this method call when user click  left or right arror of pagination
        let noOfStep = 0;
        if (event.skipCount !== 0) {
            noOfStep = event.skipCount / event.count;
        }
        this.detailsPagination = {
            count: event.maxItems,
            totalItems: event.totalItems,
            skipCount: event.skipCount,
            maxItems: event.maxItems,
            hasMoreItems: this.isNextPagination(noOfStep, event.totalItems, event.count)
        };
        if (event.maxItems > event.totalItems) {
            this.getAllUser(0, event.totalItems, false, true, '');
        } else {
            this.getAllUser(this.detailsPagination.skipCount / event.maxItems, event.maxItems, false, true, '');
        }
    }

    changeSizeItemDetailPagi(event: Pagination): void {
        this.detailsPagination = { count: event.maxItems, totalItems: event.totalItems, skipCount: 0, maxItems: event.maxItems, hasMoreItems: true };
        this.processDetailPagination(this.detailsPagination);
    }
    private isNextPagination(noOfStep: number, totalItem: number, count: number): boolean {
        return ((++noOfStep) * count) < totalItem;
    }
    onAdd(data) {
        this.userMasterModel = new UserMasterModel(data);
        console.log(this.userMasterModel);
    }
    onUpdate(data) {
        this.userMasterModel = new UserMasterModel(data);
        console.log(this.userMasterModel);
    }
    onDelete(result): void {
        console.log(result);
    }
    public onSearchResponse(event): void {
        if (event.firstName !== undefined) {
            this.searchData = (event);
        } else {
            this.searchData = { 'param': event };
        }
        this.getAllUser(0, this.PERPAGEITEMSIZE, true, true, '');
    }
    getAllStatusMasters() {
        this.userMasterService.getAllStatusMaster().subscribe((res: any) => {
            this.statusMasterList = res;
        }, (err) => {
            console.log(JSON.stringify(err));
        });
    }
}
