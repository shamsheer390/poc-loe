/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {Component, OnInit} from '@angular/core';
import {ObjectDataTableAdapter} from 'ng2-alfresco-datatable';
import {Pagination} from 'alfresco-js-api';
import {UserEntityService} from './services/user-entity.service';
import {PageEvent} from '@angular/material';
import {UserEntityMappingModel} from '../../models/user-entity-mapping.model';
import {FieldDetails} from '../../models/mu-field.model';
import {Validators} from '@angular/forms';

@Component({
  selector: 'entity-master',
  templateUrl: './user-entity.component.html',
  styleUrls: ['./user-entity.component.scss'],
  providers: [UserEntityService]
})
export class UserEntityComponent implements OnInit {
  data: ObjectDataTableAdapter;
  PERPAGEITEMSIZE: number = 5;
  detailsPagination: Pagination;
  userentityMappingModel: UserEntityMappingModel;
  formData: FieldDetails<any>[];
  deletedRecord = [];
  searchData = {};
  isSearch: boolean = false;
  getAllEntityData = [];
  showAdd: boolean = true;
  showRemove: boolean = true;
  showSave: boolean = true;
  pageEvent: PageEvent;
  mutltiSelect: boolean = true; // this property for enabled checkBox for select
  header = 'User Entity Mapping ';
  addHeader = 'Add User Entity Mapping';
  editHeader = 'Edit User Entity Mapping';
  showPagination: boolean = true;
  searchFormFiled: FieldDetails<any>[] = [  // firstName,lastName,email,userStatus,entityStatus,entityCode,entityName
    {
      label: 'FirstName',
      id: 'firstName',
      name: 'firstName',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter First Name',
      disabled: false,
      cssClass: 'mu-inputField',
      visibility: true,
      width: 4,
      value: null
    },
    {
      label: 'last Name',
      id: 'lastName',
      name: 'lastName',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter User Last Name',
      disabled: false,
      cssClass: 'mu-inputField',
      visibility: true,
      width: 4,
      value: null
    },
    {
      label: 'User Status',
      id: 'userStatus',
      name: 'userStatus',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter User Status',
      disabled: false,
      cssClass: 'mu-inputField',
      visibility: true,
      width: 4,
      value: null
    },
    {
      label: 'Entity Status',
      id: 'entityStatus',
      name: 'entityStatus',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter Entity Status',
      disabled: false,
      cssClass: 'mu-inputField',
      visibility: true,
      width: 4,
      value: null
    },
    {
      label: 'Entity Code',
      id: 'entityCode',
      name: 'entityCode',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter Entity Code',
      disabled: false,
      cssClass: 'mu-inputField',
      visibility: true,
      width: 4,
      value: null
    },
    {
      label: 'Entity Name',
      id: 'entityName',
      name: 'entityName',
      type: 'text',
      controlType: 'textbox',
      placeholder: 'Enter Entity Name',
      disabled: false,
      cssClass: 'mu-inputField',
      visibility: true,
      width: 4,
      value: null
    },
    {
      name: 'Save',
      type: 'submit',
      controlType: 'button'
    },
    {
      name: 'Close',
      type: 'button',
      controlType: 'button'
    }
  ];

  constructor(private entityMastersService: UserEntityService) {

  }

  ngOnInit() {
    this.searchData = {};
    this.formFieldJson(); // this for getting form Filled json
    this.getAllEntity(0, this.PERPAGEITEMSIZE, true, true, ''); // this method call when page load to get entity master data
  }

  private getAllEntity(offset: number, limit: number, isDefaultCall: boolean, isNotSearchCall: boolean, searchText: any): void {
    this.formFieldJson();
    this.entityMastersService.getAllEntityMaster(offset, limit, this.searchData).subscribe((res: any) => {
      this.getAllEntityData = res.content;
      if (isDefaultCall) {
        if (res.totalElements > this.PERPAGEITEMSIZE) {
          this.detailsPagination = {
            count: this.PERPAGEITEMSIZE,
            totalItems: res.totalElements,
            skipCount: 0,
            maxItems: 5,
            hasMoreItems: true
          };
        } else {
          this.detailsPagination = {
            count: this.PERPAGEITEMSIZE,
            totalItems: res.totalElements,
            skipCount: 0,
            maxItems: 5,
            hasMoreItems: false
          };
        }
      }
      this.addDataOnTable();
    });
  }

  public onAdd(data) {
    if (data.entityId !== null) {
      this.userentityMappingModel = new UserEntityMappingModel(data);
      this.entityMastersService.saveEntity(this.userentityMappingModel).subscribe((res: any) => {
        this.getAllEntity(0, this.PERPAGEITEMSIZE, true, true, '');
      }, (err) => {
        console.log(JSON.stringify(err));
      });
    }
  }

  public addDataOnTable(): void {
    this.data = new ObjectDataTableAdapter(this.getAllEntityData,
      [
        {type: 'text', key: 'entityId', title: 'Entity Id', sortable: true},
        {type: 'text', key: 'userEntityMappingId', title: 'User Entity Mapping Id', sortable: true},
        {type: 'text', key: 'userId', title: 'User Id', sortable: true},
        {type: 'date', key: 'createdOn', title: 'Created Date', sortable: true},
        {type: 'text', key: 'createBy', title: 'Created By', sortable: true},
        {type: 'date', key: 'modifiedOn', title: 'Modified Date', sortable: true},
        {type: 'text', key: 'modifiedBy', title: 'Modified By', sortable: true},
        {type: 'text', key: 'status', title: 'Status', sortable: true}
      ]);
  }

  public onUpdate(data): void {
    this.userentityMappingModel = new UserEntityMappingModel(data);
    console.log(this.userentityMappingModel);
    this.entityMastersService.saveEntity(this.userentityMappingModel).subscribe((res: any) => {
      this.getAllEntity(0, this.PERPAGEITEMSIZE, true, true, '');
    });
  }

  public onDelete(result): void {// this method for delete the single entity or multiple entity
    this.deletedRecord = [];
    if (result.length > 0) {
      result.forEach(element => {
        this.deletedRecord.push({'entityId': element.entityId, 'userId': element.userId});
      });
      this.entityMastersService.deleteEntity(this.deletedRecord).subscribe((res: any) => {
        console.log(res);
      }, (err) => {
        console.log(JSON.stringify(err));
      });
    }
  }

  public processDetailPagination(event: Pagination): void { //  this method call when user click  left or right arror of pagination
    let noOfStep = 0;
    console.log(event);
    if (event.skipCount !== 0) {
      noOfStep = event.skipCount / event.count;
    }
    this.detailsPagination = {
      count: event.maxItems,
      totalItems: event.totalItems,
      skipCount: event.skipCount,
      maxItems: event.maxItems,
      hasMoreItems: this.isNextPagination(noOfStep, event.totalItems, event.count)
    };
    if (event.maxItems > event.totalItems) {
      this.getAllEntity(0, event.totalItems, false, true, '');
    } else {
      this.getAllEntity(this.detailsPagination.skipCount / event.maxItems, event.maxItems, false, true, '');
    }
  }

  public changeSizeItemDetailPagi(event: Pagination): void {
    this.detailsPagination = {
      count: event.maxItems,
      totalItems: event.totalItems,
      skipCount: 0,
      maxItems: event.maxItems,
      hasMoreItems: true
    };
    this.processDetailPagination(this.detailsPagination);
  }

  private isNextPagination(noOfStep: number, totalItem: number, count: number): boolean {
    return ((++noOfStep) * count) < totalItem;
  }

  public onResponseSearch(event): void {
    if (event.entityCode !== undefined) {
      this.searchData = event;
    } else {
      this.searchData = {'param': event};
    }
    console.log('searchdata', this.searchData);
    this.getAllEntity(0, this.PERPAGEITEMSIZE, true, true, '');
  }

  private formFieldJson(): void { // this for add and update form when we will remove entityId then same json will use for advance search
    this.formData = [
      {
        label: 'User Entity Mapping Id',
        id: 'userEntityMappingId',
        name: 'userEntityMappingId',
        type: 'text',
        controlType: 'textbox',
        placeholder: 'Enter User Entity Mapping Id',
        disabled: false,
        cssClass: 'mu-inputField',
        visibility: false,
        width: 6,
        value: null
      },
      {
        label: 'Entity Id',
        id: 'entityId',
        name: 'entityId',
        type: 'text',
        controlType: 'textbox',
        placeholder: 'Enter Entity Id',
        disabled: false,
        cssClass: 'mu-inputField',
        visibility: true,
        width: 6,
        value: null
      },
      {
        label: 'User Id',
        id: 'userId',
        name: 'userId',
        type: 'text',
        controlType: 'textbox',
        placeholder: 'Enter User Id',
        disabled: false,
        validation: [Validators.required],
        cssClass: 'mu-inputField',
        visibility: true,
        width: 6,
        value: null
      },
      {
        name: 'Save',
        type: 'submit',
        controlType: 'button'
      },
      {
        name: 'Close',
        type: 'button',
        controlType: 'button'
      }
    ];
  }
}
