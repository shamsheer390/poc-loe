/*!
 * @license
 * Copyright 2017 Muraai Information Technologies, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 import { ModuleWithProviders }  from '@angular/core';
 import { Routes, RouterModule } from '@angular/router';
 import { AuthGuardBpm, AuthGuardEcm } from 'ng2-alfresco-core';
 import {
    InvoiceSummaryComponent,
    LoginDemoComponent,
    SettingComponent,
    InvoiceUpload,
    MyTaskInboxComponent,
    ADFTaskFromComponent,
    ADFDocuemntListComponent,
    ADFDocuemntViewerComponent,
    InvoiceDetailsLayoutComponent,
    UserMasterComponent,
    EntityMasterComponent,
    DemoComponent,
    MenuMasterComponent,
    GroupMasterComponent,
    UserEntityComponent,
    MuraaiStatusSpinnerDemoComponent,
    MenuUserGroupEntityMasterComponent,
    ClientComponent,
    ClientUpload,
    ClientFormComponent,
    MuraaiSignatureDemoComponent
} from './components';
import {ChartDashboard} from './components/chart-dashboard/chart-dashboard.component';
import {DataExtractionStatusComponent} from './components/data-extraction-status/dataextractionstatus.component';
import {DemoSearchComponent} from './components/muraai/muraai-search/src/muraai-search-demo';

 export const appRoutes: Routes = [
     { path: 'login', component: LoginDemoComponent },
     { path: 'settings', component: SettingComponent },
     { path: '', redirectTo: 'ap/client-verfication', pathMatch: 'full'},
     { path: 'ap/invoice-summary', component: InvoiceSummaryComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/invoice-upload', component: InvoiceUpload, canActivate: [ AuthGuardEcm] },
     { path: 'ap/invoice-summary/:hid/:id', component: InvoiceDetailsLayoutComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/tasks', component: MyTaskInboxComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/dashboard', component: ChartDashboard, canActivate: [AuthGuardBpm] },
     { path: 'ap/task/:taskId', component: ADFTaskFromComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/invoice-list', component: ADFDocuemntListComponent, canActivate: [AuthGuardEcm] },
     { path: 'ap/invoice-viewer', component: ADFDocuemntViewerComponent, canActivate: [AuthGuardEcm] },
     { path: 'ap/data-extraction-status' , component: DataExtractionStatusComponent, canActivate: [ AuthGuardBpm ] },
     { path: 'ap/user-master', component: UserMasterComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/entity-master', component: EntityMasterComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/search-demo', component: DemoSearchComponent },
     { path: 'ap/form-demo' , component: DemoComponent },
     { path: 'ap/group-master', component: GroupMasterComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/menu-master', component: MenuMasterComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/user-entity-mapping-master', component: UserEntityComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/status-spinner-demo', component: MuraaiStatusSpinnerDemoComponent },
     { path: 'ap/menu-configuration', component: MenuUserGroupEntityMasterComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/client-verfication', component: ClientComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/client-upload', component: ClientUpload, canActivate: [AuthGuardBpm] },
     { path: 'ap/client-form', component: ClientFormComponent, canActivate: [AuthGuardBpm] },
     { path: 'ap/signature', component: MuraaiSignatureDemoComponent }
 ];

 export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes, {useHash: true});
